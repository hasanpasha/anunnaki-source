import enum


class Kind(enum.Enum):
    MOVIES = "movies"
    SERIES = "series"
