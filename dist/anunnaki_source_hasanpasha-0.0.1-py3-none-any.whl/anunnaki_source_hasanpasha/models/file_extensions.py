from enum import Enum


class FileExtension(Enum):
    SRT = "srt"
    VTT = "vtt"
    ASS = "ass"
